/*************************************************************************/
/* File:        project4.c                                               */
/* Description: User project #4 - empty project directory for project    */
/*              developement                                             */
/* Date:        03-30-2013                                               */
/*************************************************************************/
#include <math.h>
#include <stdio.h>
#include "Xkw/Xkw.h"
#include "Roger.h"
#include "simulate.h"
#include "control.h"
#include "modes.h"

 	 Observation  obs;


void project4_control(roger, time)
Robot* roger;
double time;
{ 

//ChasePunch();
Chase(roger,time);
}

/************************************************************************/
void project4_reset(roger)
Robot* roger;
{ }

// prompt for and read user customized input values
void project4_enter_params() 
{
  printf("Project 4 enter_params called. \n");
}

//function called when the 'visualize' button on the gui is pressed
void project4_visualize(roger)
Robot* roger;
{ }
 void Chase(roger,time)
 Robot* roger;
double time;
 {

 	SEARCHTRACK(roger, time);
 	
 		roger->base_setpoint[X]=-obs.pos[X];
		roger->base_setpoint[Y]=obs.pos[Y];
 




 }
 void Punch(){
 	inv_arm_kinematics();
 }

