/****************************************************************/
/** kalman.c: kalman filter for tracking the ball              **/
/** author:   Grupen                                           **/
/** date:     Fall 2014                                        **/
/****************************************************************/
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "roger.h"
#include "simulate.h"
#include "control.h"
#include "modes.h"

void kalman_filter(roger, time)
Robot * roger;
double time;
{ }
